<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.php');
	exit;
}
//select.php

include('database_connection.php');

if(isset($_POST["id"]))
{
	$query = "SELECT * FROM tbl_name WHERE id='".$_POST["id"]."'";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$name = '';
	$cognome = '';
	$email = '';
	$contributo = '';
	$note = '';
	foreach($result as $row)
	{
		$name = $row["name"];
		$cognome = $row["cognome"];
		$email = $row["email"];
		$contributo = $row["contributo"];
		$note = $row["note"];
		$count = 1;
	}
	$output = array(
		'name'					=>	$name,
		'cognome'				=>	$cognome,
		'email'					=>	$email,
		'contributo'			=>	$contributo,
		'note'					=>	$note
	);
	echo json_encode($output);
}


?>