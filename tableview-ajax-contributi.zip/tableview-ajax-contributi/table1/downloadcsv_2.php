<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.php');
	exit;
}

	$connect = mysqli_connect("31.11.39.26", "Sql1507428", "p430p18815", "Sql1507428_4");
	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename=clienti-attesa-contributo.csv');
	$output = fopen("php://output", "w");
	fputcsv($output, array('Nome', 'Cognome' , 'email', 'Inserito-il', 'data-azione', 'fare-sollecito-il', 'contributo', 'note'));
	$query = "SELECT * FROM tbl_name WHERE verifica=2 ORDER BY data_inserimento DESC";
	$result = mysqli_query($connect, $query);
	while($row = mysqli_fetch_assoc($result))
	{
		$timeStamp = $row['data_inserimento'];
		$timeStamp = date( "d-m-Y", strtotime($timeStamp));
		$timeStampdr = $row['data_richiesta'];
		$timeStampdr = date( "d-m-Y", strtotime($timeStampdr));
		$timeStamp20d= date('d-m-Y', strtotime($timeStampdr. ' + 20 days')); 
		$user = array(
		 'Nome' => $row['name'],
		 'Cognome' => $row['cognome'],
		 'email' => $row['email'],
		 'data-inserimento' => $timeStamp,
		 'data-azione' => $timeStampdr,
		 'fare-sollecito-il' => $timeStamp20d,
		 'contributo' => $row['contributo'],
		 'note' => $row['note']
		);
		fputcsv($output, $user);
	}
		fclose($output);
?>