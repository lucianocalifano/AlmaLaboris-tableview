<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.php');
	exit;
}

//database_connection.php

$connect = new PDO("mysql:host=31.11.39.26;dbname=Sql1507428_4", "Sql1507428", "p430p18815");


?>