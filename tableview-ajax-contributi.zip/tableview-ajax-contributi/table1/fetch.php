<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.php');
	exit;
}

//fetch.php

include('database_connection.php');

$num_step = $_POST["step"];
//echo($num_step);

$query = "SELECT * FROM tbl_name WHERE verifica = ". $num_step ." ORDER BY data_inserimento DESC";


$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

$total_rows = $statement->rowCount();


if($num_step==0){
$output = '
<div class="table table-bordered table-striped">
	<table class="table">
		<tr>
			<th>Nome</th>
			<th>Cognome</th>
			<th>Email</th>
			<th>Inserito il</th>
			<th>Modifica</th>
			<th>Elimina</th>
			<th>Azione</th>
		</tr>
';
	if($total_rows > 0)
{
	foreach($result as $row)
	{
		$timeStamp = $row['data_inserimento'];
		$timeStamp = date( "d-m-Y", strtotime($timeStamp));
		$output .= '
		<tr>
			<td>'.$row["name"].'</td>
			<td>'.$row["cognome"].'</td>
			<td>'.$row["email"].'</td>
			<td>'.$timeStamp.'</td>
			<td><button type="button" name="edit" id="'.$row["id"].'" class="btn btn-warning btn-xs edit">Edit</button></td>
			<td><button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete">Delete</button></td>
			<td><button type="submit" name="check" id="'.$row["id"].'"  class="btn btn-success btn-xs check ">Avanti</button></td>
		</tr>
		';
	}
}
else
{
	$output .= '
	<tr>
		<td colspan="4">Nessun dato trovato.</td>
	</tr>
	';
}
$output .= '</table></div>';

echo $output;

}

else if($num_step==3){
$output = '
<div class="table table-bordered table-striped">
	<table class="table">
		<tr>
			<th>Nome</th>
			<th>Cognome</th>
			<th>Email</th>
			<th>Inserito il</th>
			<th>Contributo ricevuto</th>
			<th>Note</th>
			<th>Modifica</th>
			<th>Elimina</th>
			<th>Azione</th>
		</tr>
';
	if($total_rows > 0)
{
	foreach($result as $row)
	{
		$timeStamp = $row['data_inserimento'];
		$timeStamp = date( "d-m-Y", strtotime($timeStamp));
		$timeStampdr = $row['data_richiesta'];
		$timeStampdr = date( "d-m-Y", strtotime($timeStampdr));
		$timeStampdc = $row['data_contributo'];
		$timeStampdc = date( "d-m-Y", strtotime($timeStampdc));
		$output .= '
		<tr>
			<td>'.$row["name"].'</td>
			<td>'.$row["cognome"].'</td>
			<td>'.$row["email"].'</td>
			<td>'.$timeStamp.'</td>
			<td>'.$row["contributo"].'</td>
			<td>'.$row["note"].'</td>
			<td><button type="button" name="edit" id="'.$row["id"].'" class="btn btn-warning btn-xs edit">Edit</button></td>
			<td><button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete">Delete</button></td>
			<td><button type="submit" name="check" id="'.$row["id"].'"  class="btn btn-success  btn-xs check ">Pubblicato</button></td>
		</tr>
		';
	}
	
}
else
{
	$output .= '
	<tr>
		<td colspan="4">Nessun dato trovato.</td>
	</tr>
	';
}
$output .= '</table></div>';

echo $output;

}

else if($num_step==4){
$output = '
<div class="table table-bordered table-striped">
	<table class="table">
		<tr>
			<th>Nome</th>
			<th>Cognome</th>
			<th>Email</th>
			<th>Inserito il</th>
			<th>data pubblicazione contributo</th>
			<th>Contributo ricevuto e pubblicato</th>
			<th>Note</th>
			<th>Elimina</th>
		</tr>
';
	if($total_rows > 0)
{
	foreach($result as $row)
	{
		$timeStamp = $row['data_inserimento'];
		$timeStamp = date( "d-m-Y", strtotime($timeStamp));
		$timeStampdr = $row['data_richiesta'];
		$timeStampdr = date( "d-m-Y", strtotime($timeStampdr));
		$timeStampdc = $row['data_contributo'];
		$timeStampdc = date( "d-m-Y", strtotime($timeStampdc));
		$timeStampdp = $row['data_pubblicazione'];
		$timeStampdp = date( "d-m-Y", strtotime($timeStampdp));
		$output .= '
		<tr>
			<td>'.$row["name"].'</td>
			<td>'.$row["cognome"].'</td>
			<td>'.$row["email"].'</td>
			<td>'.$timeStamp.'</td>
			<td>'.$timeStampdp.'</td>
			<td>'.$row["contributo"].'</td>
			<td>'.$row["note"].'</td>
			<td><button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete">Delete</button></td>
		</tr>
		';
	}
	
}
else
{
	$output .= '
	<tr>
		<td colspan="4">Nessun dato trovato.</td>
	</tr>
	';
}
$output .= '</table></div>';

echo $output;

}

else if($num_step==2){
$output = '
<div class="table table-bordered table-striped">
	<table class="table">
		<tr>
			<th>Nome</th>
			<th>Cognome</th>
			<th>Email</th>
			<th>Inserito il</th>
			<th>data Azione</th>
			<th>fare sollecito il</th>
			<th>Contributo ricevuto</th>
			<th>Note</th>
			<th>Modifica</th>
			<th>Elimina</th>
			<th>Azione</th>
		</tr>
';
	if($total_rows > 0)
{
	foreach($result as $row)
	{
		$timeStamp = $row['data_inserimento'];
		$timeStamp = date( "d-m-Y", strtotime($timeStamp));
		$timeStampdr = $row['data_richiesta'];
		$timeStampdr = date( "d-m-Y", strtotime($timeStampdr));
		$timeStamp20d= date('d-m-Y', strtotime($timeStampdr. ' + 20 days')); 
		$output .= '
		<tr>
			<td>'.$row["name"].'</td>
			<td>'.$row["cognome"].'</td>
			<td>'.$row["email"].'</td>
			<td>'.$timeStamp.'</td>
			<td>'.$timeStampdr.'</td>
			<td>'.$timeStamp20d.'</td>
			<td>'.$row["contributo"].'</td>
			<td>'.$row["note"].'</td>
			<td><button type="button" name="edit" id="'.$row["id"].'" class="btn btn-warning btn-xs edit">Edit</button></td>
			<td><button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete">Delete</button></td>
			<td><button type="submit" name="check" id="'.$row["id"].'"  class="btn btn-success  btn-xs check ">Avanti</button></td>
		</tr>
		';
	}
	
}
else
{
	$output .= '
	<tr>
		<td colspan="4">Nessun dato trovato.</td>
	</tr>
	';
}
$output .= '</table></div>';

echo $output;

}


else if($num_step==1){
			$output = '
		<div class="table table-bordered table-striped">
		<table class="table">
		<tr>
			<th>Nome</th>
			<th>Cognome</th>
			<th>Email</th>
			<th>Inserito il</th>
			<th>data Azione</th>
			<th>fare sollecito il</th>
			<th>Contributo aspettato</th>
			<th>Note</th>
			<th>riscontro</th>
			<th>Modifica</th>
			<th>Azione</th>
		</tr>
';

 if($total_rows > 0)
{
	foreach($result as $row)
	{
		$timeStamp = $row['data_inserimento'];
		$timeStamp = date( "d-m-Y", strtotime($timeStamp));
		$timeStampdr = $row['data_richiesta'];
		$timeStampdr = date( "d-m-Y", strtotime($timeStampdr));
		$timeStamp20d= date('d-m-Y', strtotime($timeStampdr. ' + 20 days')); 
		$output .= '
		<tr>
			<td>'.$row["name"].'</td>
			<td>'.$row["cognome"].'</td>
			<td>'.$row["email"].'</td>
			<td>'.$timeStamp.'</td>
			<td>'.$timeStampdr.'</td>
			<td>'.$timeStamp20d.'</td>
			<td><input type="checkbox" class="get_value" value="Video" /> Video<br />
			<input type="checkbox" class="get_value" value="Intervista" /> Intervista<br />
			<input type="checkbox" class="get_value" value="Articolo" /> Articolo<br /></td>
			<td>'.$row["note"].'</td>
			<td><button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete">Negativo</button></td>
			<td><button type="submit" name="edit" id="'.$row["id"].'" class="btn btn-warning btn-xs edit">Edit</button></td>
			<td><button type="submit" name="check" id="'.$row["id"].'"  class="btn btn-success btn-xs check">Avanti</button></td>
		</tr>
		';
	}
}
else
{
	$output .= '
	<tr>
		<td colspan="4">Nessun dato trovato.</td>
	</tr>
	';
}
$output .= '</table></div>';

echo $output;

	}
	
?>