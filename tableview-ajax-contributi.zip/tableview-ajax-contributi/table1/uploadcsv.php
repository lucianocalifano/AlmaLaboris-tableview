<?php
use Phppot\DataSource;
require_once 'DataSource.php';
$db = new DataSource();
$conn = $db->getConnection();

if (isset($_POST["import"])) {
    
    $fileName = $_FILES["file"]["tmp_name"]; 
    if ($_FILES["file"]["size"] > 0) {
        
        $file = fopen($fileName, "r");
        while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
           
            $name = "";
            if (isset($column[0])) {
                $name = mysqli_real_escape_string($conn, $column[0]);
            }
            $cognome = "";
            if (isset($column[1])) {
                $cognome = mysqli_real_escape_string($conn, $column[1]);
            }
            $email = "";
            if (isset($column[2])) {
                $email = mysqli_real_escape_string($conn, $column[2]);
            }
			$master = "";
            if (isset($column[3])) {
                $master = mysqli_real_escape_string($conn, $column[3]);
            }
            
            $sqlInsert = "INSERT into tbl_name (name,cognome,email,contributo)
            values (?,?,?,?)";
            $paramType = "ssss";
            $paramArray = array(
                $name,
                $cognome,
                $email,
                $contributo
            );
            $insertId = $db->insert($sqlInsert, $paramType, $paramArray);
            
            if (! empty($insertId)) {
                $type = "success";
                $message = "CSV Data Imported into the Database";
            } else {
                $type = "error";
                $message = "Problem in Importing CSV Data";
            }
        }
    }
				header("Location: index.php");
}
?>