<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.php');
	exit;
}

//delete.php

include('database_connection.php');
$num_step = $_POST["step"];
$selezionati = $_POST["selezionati"];
//echo($selezionati);

//prevedere un if per verificare lo step e quindi andare poi ad iniserire la data verifica in base allo step

if($num_step==0){
if(isset($_POST["id"]))
{
	$query = "UPDATE tbl_name 
		SET verifica = ". $num_step .",
		data_richiesta= now()
		WHERE id = '".$_POST['id']."'";
	$statement = $connect->prepare($query);
	$statement->execute();
}
	}
	
if($num_step==1){
if(isset($_POST["id"]))
{
	$query = "UPDATE tbl_name 
		SET verifica = ". $num_step .",
		data_richiesta= now()
		WHERE id = '".$_POST['id']."'";
	$statement = $connect->prepare($query);
	$statement->execute();
}
	}
	
if($num_step==2){
if(isset($_POST["id"]))
{
	$query = "UPDATE tbl_name 
		SET verifica = ". $num_step .",
		contributo = '".$_POST['selezionati']."',
		data_riscontro= now(),
		data_richiesta= now()
		WHERE id = '".$_POST['id']."'"; 
	$statement = $connect->prepare($query);
	$statement->execute();
}
	}

if($num_step==3){
if(isset($_POST["id"]))
{
	$query = "UPDATE tbl_name 
		SET verifica = ". $num_step .",
		data_contributo= now(),
		data_richiesta= now()
		WHERE id = '".$_POST['id']."'";
	$statement = $connect->prepare($query);
	$statement->execute();
}
	}
	
if($num_step==4){
if(isset($_POST["id"]))
{
	$query = "UPDATE tbl_name 
		SET verifica = ". $num_step .",
		data_pubblicazione= now()
		WHERE id = '".$_POST['id']."'";
	$statement = $connect->prepare($query);
	$statement->execute();
}
	}
	

?>