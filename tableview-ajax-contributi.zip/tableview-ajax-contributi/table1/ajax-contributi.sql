-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: 31.11.39.26
-- Generato il: Mar 08, 2021 alle 11:44
-- Versione del server: 5.7.32-35-log
-- Versione PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Sql1507428_4`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `tbl_name`
--

CREATE TABLE IF NOT EXISTS `tbl_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `cognome` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `data_inserimento` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_richiesta` timestamp NULL DEFAULT NULL,
  `contributo` varchar(50) DEFAULT NULL,
  `verifica` int(11) DEFAULT '0',
  `data_riscontro` timestamp NULL DEFAULT NULL,
  `data_contributo` timestamp NULL DEFAULT NULL,
  `data_pubblicazione` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=189 ;

--
-- Dump dei dati per la tabella `tbl_name`
--

INSERT INTO `tbl_name` (`id`, `name`, `cognome`, `email`, `data_inserimento`, `data_richiesta`, `contributo`, `verifica`, `data_riscontro`, `data_contributo`, `data_pubblicazione`) VALUES
(185, 'kevin_tom', 'kevin', 'Kevin@email.it', '2021-03-08 09:04:54', NULL, NULL, 0, NULL, NULL, NULL),
(186, 'vincy', 'vincy', 'Vincy@email.it', '2021-03-08 09:04:54', NULL, NULL, 0, NULL, NULL, NULL),
(177, 'kevin_tom', 'kevin', 'Kevin@email.it', '2021-03-08 08:33:08', NULL, NULL, 0, NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
