<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.php');
	exit;
}

//insert.php

include('database_connection.php');

if(isset($_POST["id"]))
{
	$query = "INSERT INTO tbl_name (name, cognome, email) VALUES (:name, :cognome, :email )";
	$statement = $connect->prepare($query);
	$statement->execute();
}


?>