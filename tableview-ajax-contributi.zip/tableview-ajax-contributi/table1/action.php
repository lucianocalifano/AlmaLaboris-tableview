<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.php');
	exit;
}

//action.php

include('database_connection.php');

if(isset($_POST["action"]))
{
	$data = array(
		':name'						=>	$_POST["name"],
		':cognome'					=>	$_POST["cognome"],
		':email'					=>	$_POST["email"]
	);
	
	$query = '';
	if($_POST["action"] == "insert")
	{
		$query = "INSERT INTO tbl_name (name, cognome, email) VALUES (:name, :cognome, :email)";
	}
	
	if($_POST["action"] == "edit")
	{
		$data = array(
		':name'						=>	$_POST["name"],
		':cognome'					=>	$_POST["cognome"],
		':email'					=>	$_POST["email"],
		':contributo' 				=> 	$_POST["contributo"],
		':note' 					=> 	$_POST["note"]
	);
		
		$query = "
		UPDATE tbl_name 
		SET name = :name, 
		cognome = :cognome, 
		email = :email,
	    contributo = :contributo,
		note = :note
		WHERE id = '".$_POST['hidden_id']."'
		";
	}
	
	$statement = $connect->prepare($query);
	$statement->execute($data);
}


?>