<!--index.php !-->
<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.php');
	exit;
}
?>
<html>
	<head>
		<title>Contribute to Alma Laboris</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
                <link rel="icon" href="https://www.almalaboris.com/ajax-contributi/table1/favicon.ico" type="image/x-icon">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<br />
			<br />
			<h2 align="center">First table contribute to Alma Laboris monitoring</h2>
			<a href="logout.php" style="float:inline-end">Logout</a><br>
			<nav class="navbar navbar-expand-sm bg-light justify-content-center">
			<ul class="nav nav-pills">
			<li class="nav-item">
			<a class="nav-link" href="https://www.almalaboris.com/ajax-contributi/table1">Inserimento e prima richiesta</a></li>
			<li class="nav-item">
			<a class="nav-link" href="https://www.almalaboris.com/ajax-contributi/table1/index2.php">Monitoraggio riscontro</a></li>
			<li class="nav-item">
			<a class="nav-link" href="https://www.almalaboris.com/ajax-contributi/table1/index3.php">In Attesa Contributo</a></li>
			<li class="nav-item">
			<a class="nav-link" href="https://www.almalaboris.com/ajax-contributi/table1/index4.php">Da Pubblicare</a></li>
			<li class="nav-item">
			<a class="nav-link active" href="https://www.almalaboris.com/ajax-contributi/table1/index5.php">Pubblicato</a></li>
			</ul></nav><br>
			<br />
			<div align="right">
				<button type="button" name="download" id="download" class="btn btn-primary" onclick="downloadCSV()">Download table</button>
			</div><br>
			<div id="result"></div>
		</div>
	</body>
</html>

<div id="dynamic_field_modal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<form method="post" id="add_name">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Aggiungi campi utente</h4>
				</div>
				<div class="modal-body">
					<div class="form-group">
		      			<input type="text" name="name" id="name" class="form-control" placeholder="Enter your name" /><br>
		      		<!--<div class="table-responsive">
		      			<table class="table" id="dynamic_field" style="display:hidden">

		      			</table>
		      		</div>-->
						<input type="text" name="cognome" id="cognome" class="form-control" placeholder="Enter your cogname" /><br>
						<input type="text" name="email" id="email" class="form-control" placeholder="Enter your email" /><br>
						<input type="text" name="contributo" id="contributo" class="form-control" placeholder="Enter your contributo" /><br>
					</div>
				</div>
				<div class="modal-footer">
					<input type="hidden" name="hidden_id" id="hidden_id" />
					<input type="hidden" name="action" id="action" value="insert" />
					<!--<input type="hidden" name="action" id="action" value="check" /> male male --> 
					<input type="submit" name="submit" id="submit" class="btn btn-primary" value="Submit" />
				</div>
			</form>
		</div>
	</div>

</div>


<script>
function downloadCSV() {
    $.ajax({
    url: 'https://www.almalaboris.com/ajax-contributi/table1/downloadcsv_4.php',
    type: 'GET',
	success: function() {
        window.location = 'https://www.almalaboris.com/ajax-contributi/table1/downloadcsv_4.php';
		}
	});
}

$(document).ready(function(){


	var count = 1;

	function load_data()
	{
		$.ajax({
			url:"fetch.php",
			method:"POST",
			data:{step:"4"},
			success:function(data)
			{
				$('#result').html(data);
			}
		})
	}
	
	load_data();
	
	$(document).on('click', '.check', function(){
		var id = $(this).attr("id");
		if(confirm("Are you sure want to migrate this data?"))
	{
		$.ajax({
			url:"check.php",
			method:"POST",
			data:{id:id, step:"5"},
			dataType:"JSON",
			success:function(data)
			{
				$('#action').val('check');
				$('#submit').val("Check");
				$('#hidden_id').val(id);
				alert("Data migrated");
                                load_data();
                                window.location.reload();
			}
		});
	}
			load_data();
});

	function add_dynamic_input_field(count)
	{
		var button = '';
		if(count > 1)
		{
			button = '<button type="button" name="remove" id="'+count+'" class="btn btn-danger btn-xs remove">x</button>';
		}
		else
		{
			button = '<button type="button" name="add_more" id="add_more" class="btn btn-success btn-xs">+</button>';
		}
		output = '<tr id="row'+count+'">';
		output += '<td><input type="text" name="programming_languages[]" placeholder="Add Programming Languages" class="form-control name_list" /></td>';
		output += '<td align="center">'+button+'</td></tr>';
		$('#dynamic_field').append(output);
	}

	$('#add').click(function(){
		$('#dynamic_field').html('');
		add_dynamic_input_field(1);
		$('.modal-title').text('Add Details');
		$('#action').val("insert");
		$('#submit').val('Submit');
		$('#add_name')[0].reset();
		$('#dynamic_field_modal').modal('show');
	});

	$(document).on('click', '#add_more', function(){
		count = count + 1;
		add_dynamic_input_field(count);
	});

	$(document).on('click', '.remove', function(){
		var row_id = $(this).attr("id");
		$('#row'+row_id).remove();
	});

	$('#add_name').on('submit', function(event){
		event.preventDefault();
		if($('#name').val() == '')
		{
			alert("Enter Your Name");
			return false;
		}
		var total_languages = 0;
		$('.name_list').each(function(){
			if($(this).val() != '')
			{
				total_languages = total_languages + 1;
			}
		});

		if(total_languages >= 0)
		{
			var form_data = $(this).serialize();

			var action = $('#action').val();
			$.ajax({
				url:"action.php",
				method:"POST",
				data:form_data,
				success:function(data)
				{
					if(action == 'insert')
					{
						alert("Data Inserted");
					}
					if(action == 'edit')
					{
						alert("Data Edited");
					}
					add_dynamic_input_field(1);
					load_data();
					$('#add_name')[0].reset();
					$('#dynamic_field_modal').modal('hide');
				}
			});
		}
		else
		{
			alert("Please Enter at least one programming languages");
		}
	});

	$(document).on('click', '.edit', function(){
		var id = $(this).attr("id");
		$.ajax({
			url:"select.php",
			method:"POST",
			data:{id:id},
			dataType:"JSON",
			success:function(data)
			{
				$('#name').val(data.name);
				//$('#dynamic_field').html(data.programming_languages);
				$('#cognome').val(data.cognome);
				$('#email').val(data.email);
				$('#contributo').val(data.contributo);
				$('#action').val('edit');
				$('.modal-title').text("Edit Details");
				$('#submit').val("Modifica");
				$('#hidden_id').val(id);
				$('#dynamic_field_modal').modal('show');
			}
		});
	});

	$(document).on('click', '.delete', function(){
		var id = $(this).attr("id");
		if(confirm("Are you sure want to remove this data?"))
		{
			$.ajax({
				url:"delete.php",
				method:"POST",
				data:{id:id},
				success:function(data)
				{
					load_data();
					alert("Data removed");
				}
			})
		}
	});

});
</script>




